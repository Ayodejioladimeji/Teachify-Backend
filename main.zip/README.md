# TEACHIFY LEARNING PLATFORM

## Learn your favorite course, build your skills.Enroll free course online from world-class instructors.

## Built with NODEJS EXPRESS MONGODB SOCKET.IO

View live link below
[Teachify](https://teachify-learning.netlify.app).

![Teachify](https://res.cloudinary.com/devsource/image/upload/v1656504181/portfolio/project-one_jvk8lz.png)

## Project by Layobright
